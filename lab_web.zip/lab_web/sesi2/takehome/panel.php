<!DOCTYPE html>
<html>
<head><title>Admin Panel</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:800px;margin:auto}
h1{color:#3fb950}
.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}
.flag{color:#f0c040}
table{width:100%;border-collapse:collapse}
th{background:#21262d;padding:10px;text-align:left;color:#8b949e}
td{padding:10px;border-bottom:1px solid #21262d}
a{color:#58a6ff}
</style>
</head>
<body>
<?php
session_start();
if (empty($_SESSION['user'])) {
    header('Location: /');
    exit;
}
$db = new SQLite3('/data/admin.db');
$role = $_SESSION['role'] ?? 'viewer';
?>
<h1>Admin Panel</h1>
<div class="box">
    <p>Logged in as: <b><?php echo htmlspecialchars($_SESSION['user']); ?></b>
       (role: <b><?php echo htmlspecialchars($role); ?></b>)</p>
</div>

<?php if ($role === 'admin'): ?>
<div class="box">
    <h2>Secret Keys</h2>
    <table>
        <tr><th>Name</th><th>Value</th></tr>
        <?php
        $res = $db->query("SELECT name, value FROM secrets");
        while ($r = $res->fetchArray(SQLITE3_ASSOC)):
        ?>
        <tr>
            <td><?php echo htmlspecialchars($r['name']); ?></td>
            <td class="flag"><?php echo htmlspecialchars($r['value']); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
<?php else: ?>
<div class="box" style="border-color:#f85149">
    <p style="color:#f85149">Akses ditolak. Hanya admin yang bisa melihat secret keys.</p>
    <p style="color:#8b949e;font-size:13px">Role kamu: <?php echo htmlspecialchars($role); ?></p>
</div>
<?php endif; ?>

<p><a href="/">Logout</a></p>
</body>
</html>
