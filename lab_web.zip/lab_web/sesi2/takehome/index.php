<!DOCTYPE html>
<html>
<head><title>Admin Login</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:500px;margin:auto}
h1{color:#58a6ff}
input{width:100%;padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;margin:6px 0;box-sizing:border-box}
button{padding:10px 24px;background:#238636;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-top:10px}
.error{color:#f85149;margin:10px 0}
.info{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin-top:20px;color:#8b949e;font-size:13px}
</style>
</head>
<body>
<h1>Admin Panel Login</h1>
<?php
$db_path = '/data/admin.db';
$db = new SQLite3($db_path);
$db->exec("PRAGMA journal_mode=WAL;");
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT,
    password TEXT,
    role TEXT
)");
$db->exec("CREATE TABLE IF NOT EXISTS secrets (
    id INTEGER PRIMARY KEY,
    name TEXT,
    value TEXT
)");
if ($db->querySingle("SELECT COUNT(*) FROM users") == 0) {
    $db->exec("INSERT INTO users VALUES (1,'admin','S3cur3P4ss!2024','admin')");
    $db->exec("INSERT INTO users VALUES (2,'viewer','viewer123','viewer')");
    $db->exec("INSERT INTO secrets VALUES (1,'api_key','sk-prod-CYBER{sqli_lev3l2_un10n_3xtr4ct}')");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    $sql = "SELECT id, username, role FROM users WHERE username='" . $u . "' AND password='" . $p . "'";
    $row = @$db->querySingle($sql, true);
    if ($row && !empty($row['username'])) {
        session_start();
        $_SESSION['user'] = $row['username'];
        $_SESSION['role'] = $row['role'];
        header('Location: /panel.php');
        exit;
    }
    $error = 'Username atau password salah.';
}
?>
<?php if ($error): ?>
<p class="error"><?php echo $error; ?></p>
<?php endif; ?>
<form method="POST" action="/">
    <label>Username</label>
    <input type="text" name="username" autocomplete="off">
    <label>Password</label>
    <input type="password" name="password">
    <button type="submit">Login</button>
</form>
<div class="info">
    <p>Akun admin ada di database, tapi passwordnya tidak diketahui.</p>
    <p>Hint: Ada lebih dari satu cara untuk masuk...</p>
</div>
</body>
</html>
