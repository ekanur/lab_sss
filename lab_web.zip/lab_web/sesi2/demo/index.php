<!DOCTYPE html>
<html>
<head><title>Perpustakaan Digital</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:900px;margin:auto}
h1{color:#58a6ff}
input{padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;width:320px}
button{padding:8px 18px;background:#1f6feb;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-left:8px}
table{width:100%;border-collapse:collapse;margin-top:20px}
th{background:#21262d;padding:10px;text-align:left;color:#8b949e;font-size:13px}
td{padding:10px;border-bottom:1px solid #21262d}
.query{background:#161b22;border:1px solid #30363d;padding:12px;border-radius:4px;margin:15px 0;font-size:13px;color:#8b949e;word-break:break-all}
.error{color:#f85149;background:#161b22;border:1px solid #f85149;padding:12px;border-radius:4px;margin:15px 0}
</style>
</head>
<body>
<h1>Perpustakaan Digital Nusantara</h1>
<?php
$db_path = '/data/library.db';
$db = new SQLite3($db_path);
$db->exec("PRAGMA journal_mode=WAL;");
$db->exec("CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY,
    title TEXT,
    author TEXT,
    year TEXT,
    description TEXT
)");
$db->exec("CREATE TABLE IF NOT EXISTS secret_collection (
    id INTEGER PRIMARY KEY,
    title TEXT,
    author TEXT,
    year TEXT,
    content TEXT
)");
if ($db->querySingle("SELECT COUNT(*) FROM books") == 0) {
    $db->exec("INSERT INTO books VALUES (1,'Pemrograman Web Modern','Budi Santoso','2023','Panduan lengkap HTML CSS dan JavaScript')");
    $db->exec("INSERT INTO books VALUES (2,'Keamanan Siber Dasar','Siti Rahayu','2022','Pengenalan keamanan jaringan dan aplikasi')");
    $db->exec("INSERT INTO books VALUES (3,'Algoritma dan Struktur Data','Ahmad Fauzi','2023','Dari array hingga graph dengan contoh kode')");
    $db->exec("INSERT INTO books VALUES (4,'Python untuk Pemula','Dewi Lestari','2024','Belajar Python dari nol dengan proyek nyata')");
}
if ($db->querySingle("SELECT COUNT(*) FROM secret_collection") == 0) {
    $db->exec("INSERT INTO secret_collection VALUES (1,'Dokumen Internal Q4','Unknown','2024','CYBER{un10n_b4s3d_sqli_p3rpust4k44n}')");
}

$q      = $_GET['q'] ?? '';
$results = [];
$error   = '';
$sql_shown = '';

if ($q !== '') {
    $sql = "SELECT id, title, author, year, description FROM books WHERE title LIKE '%" . $q . "%' OR author LIKE '%" . $q . "%'";
    $sql_shown = $sql;
    try {
        $res = @$db->query($sql);
        if ($res) {
            while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
                $results[] = $row;
            }
        } else {
            $error = $db->lastErrorMsg();
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<form method="GET" action="/">
    <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>" placeholder="Cari judul atau penulis...">
    <button type="submit">Cari</button>
</form>

<?php if ($q !== ''): ?>
<div class="query">SQL: <?php echo htmlspecialchars($sql_shown); ?></div>

<?php if ($error): ?>
<div class="error">Error: <?php echo htmlspecialchars($error); ?></div>
<?php elseif (empty($results)): ?>
<p style="color:#8b949e">Tidak ada buku ditemukan.</p>
<?php else: ?>
<table>
    <tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Tahun</th><th>Deskripsi</th></tr>
    <?php foreach ($results as $r): ?>
    <tr>
        <td><?php echo htmlspecialchars($r['id']); ?></td>
        <td><?php echo htmlspecialchars($r['title']); ?></td>
        <td><?php echo htmlspecialchars($r['author']); ?></td>
        <td><?php echo htmlspecialchars($r['year']); ?></td>
        <td><?php echo htmlspecialchars($r['description']); ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>
<?php endif; ?>
</body>
</html>
