# Lab Web Exploitation — Komunitas Cyber

Lab ini berisi resource untuk uji-coba teknik **Web Exploitation** yang dipelajari di sesi Agustus, mencakup:
- Pengenalan HTTP & Burp Suite (manipulasi request, header, cookie)
- SQL Injection (login bypass, UNION-based extraction, WAF bypass)
- Cross-Site Scripting / XSS (reflected dan stored)
- Vulnerability chaining (gabungan beberapa teknik sekaligus)

Semua lab berjalan di Docker — tidak perlu install apapun selain Docker Desktop.

---

## Prasyarat

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) sudah terinstall dan berjalan
- Koneksi internet saat pertama kali build (untuk download image PHP)
- [Burp Suite Community](https://portswigger.net/burp/communitydownload) untuk sesi 1

---

## Cara Deploy

**1. Clone atau download repository ini**
```bash
git clone <URL-repo-ini>
cd <nama-folder>
```

**2. Build dan jalankan semua lab sekaligus**
```bash
docker compose up -d --build
```
> Build pertama kali membutuhkan waktu **3–5 menit** karena download image PHP dari internet.
> Build berikutnya jauh lebih cepat karena sudah di-cache.

**3. Cek semua lab berjalan**
```bash
docker compose ps
```
Semua container harus berstatus `Up`.

**4. Akses lab dari browser**

Buka `http://localhost:PORT` sesuai daftar lab di bawah.

**5. Menghentikan semua lab**
```bash
docker compose down
```

**Menjalankan hanya 1 lab tertentu (opsional)**
```bash
docker compose up -d --build sesi1-demo
```

---

## Daftar Lab

| Port | Nama Lab | Sesi | Teknik yang Dilatih |
|------|----------|------|---------------------|
| `8001` | VIP Access | Sesi 1 — Demo | Manipulasi HTTP header (`X-Forwarded-For`) menggunakan Burp Suite Repeater |
| `8002` | Cookie Monster | Sesi 1 — Take-Home | Manipulasi nilai cookie untuk eskalasi privilege (`role=user` → `role=admin`) |
| `8003` | Perpustakaan Digital | Sesi 2 — Demo | SQL Injection UNION-based pada form pencarian untuk extract tabel tersembunyi |
| `8004` | Admin Panel | Sesi 2 — Take-Home | SQL Injection login bypass + UNION SELECT untuk extract credential dari database |
| `8005` | Kotak Saran | Sesi 3 — Demo | Reflected XSS pada form pencarian, payload dikirim via URL |
| `8006` | Forum Komunitas | Sesi 3 — Take-Home | Stored XSS pada form komentar, payload tersimpan di database dan dieksekusi di `/admin.php` |
| `8007` | PT Nusantara Shop | Sesi 4 — Demo | Vulnerability chaining: SQLi → dapat credential staff → Stored XSS → steal cookie admin |
| `8008` | Perpustakaan v2 | Sesi 4 — Take-Home | SQL Injection dengan WAF sederhana — perlu bypass filter keyword menggunakan variasi case |

---

## Catatan Per Lab

### Port 8001 — VIP Access *(Sesi 1 Demo)*
Halaman `/admin.php` hanya bisa diakses dari IP `127.0.0.1`. Server mengecek header `X-Forwarded-For` untuk menentukan IP client. Gunakan Burp Suite Repeater untuk menambahkan header ini secara manual.

### Port 8002 — Cookie Monster *(Sesi 1 Take-Home)*
Login dengan akun yang tersedia (`budi` / `budi123`). Setelah login, perhatikan cookie yang dikirim server. Flag hanya muncul kalau role yang tersimpan di cookie bernilai `admin`.

### Port 8003 — Perpustakaan Digital *(Sesi 2 Demo)*
Form pencarian buku mengirim input langsung ke query SQL tanpa sanitasi. Query yang dibentuk server ditampilkan di halaman untuk membantu analisa. Ada tabel tersembunyi bernama `secret_collection` yang tidak muncul di pencarian normal.

### Port 8004 — Admin Panel *(Sesi 2 Take-Home)*
Ada dua langkah: (1) bypass login dengan SQLi untuk masuk tanpa tahu password, dan (2) extract isi tabel `secrets` menggunakan UNION SELECT. Flag hanya ditampilkan jika berhasil login sebagai user dengan role `admin`.

### Port 8005 — Kotak Saran *(Sesi 3 Demo)*
Halaman menampilkan ulang hasil pencarian tanpa encoding. Perhatikan bahwa ada cookie yang di-set oleh server saat halaman dibuka. Coba buat payload XSS yang membaca dan menampilkan isi `document.cookie`.

### Port 8006 — Forum Komunitas *(Sesi 3 Take-Home)*
Posting komentar di halaman utama (`/`), lalu buka halaman moderasi (`/admin.php`). Halaman moderasi menampilkan semua komentar tanpa sanitasi. Flag ada di cookie yang di-set oleh halaman `/admin.php` — gunakan XSS untuk membacanya.

### Port 8007 — PT Nusantara Shop *(Sesi 4 Demo)*
Challenge multi-step — perlu beberapa teknik sekaligus:
1. Daftar akun baru, explore endpoint yang tersedia
2. Temukan parameter yang vulnerable di `/profile.php`
3. Gunakan SQLi untuk extract credential akun staff
4. Login sebagai staff, masuk ke Staff Board
5. Post payload XSS di Staff Board
6. Buka halaman yang sama — XSS akan mengeksekusi dan bocorkan cookie admin
7. Gunakan cookie admin untuk akses `/admin.php` dan dapatkan flag

### Port 8008 — Perpustakaan v2 *(Sesi 4 Take-Home)*
Versi "patched" dari Perpustakaan Digital. Filter WAF memblokir keyword SQLi seperti `union` dan `select`. Coba temukan cara bypass filter ini — perhatikan bahwa filter bekerja berdasarkan pencocokan case-sensitive tertentu.

---

## Tips Umum

- Gunakan **Burp Suite Proxy** untuk semua lab — aktifkan intercept, perhatikan request yang dikirim browser
- Selalu coba input sederhana dulu (`'`, `"`, `<`) sebelum langsung pakai payload kompleks
- Perhatikan **pesan error** yang muncul — sering mengandung petunjuk penting
- Kalau stuck, coba lihat **source HTML** halaman (Ctrl+U) — kadang ada komentar atau hint tersembunyi

---

## Troubleshooting

**Container tidak mau start / status `Exited`**
```bash
docker compose logs <nama-container>
```
Lihat pesan error, biasanya terkait port yang sudah dipakai aplikasi lain.

**Port sudah dipakai aplikasi lain**

Edit file `docker-compose.yml`, ganti port kiri sesuai kebutuhan. Contoh ganti port 8001 menjadi 9001:
```yaml
ports:
  - "9001:80"
```

**Reset database lab (kalau ingin mulai dari awal)**
```bash
docker compose down
docker compose up -d --build
```
Database SQLite disimpan di dalam container — dihapus otomatis saat container di-rebuild.

**Build ulang setelah ada perubahan file**
```bash
docker compose up -d --build
```
