<!DOCTYPE html>
<html>
<head><title>Login — Sistem Komunitas</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:500px;margin:auto}
h1{color:#58a6ff}
input{width:100%;padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;margin:6px 0;box-sizing:border-box}
button{padding:10px 24px;background:#238636;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-top:10px}
.error{color:#f85149;margin:10px 0}
.info{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin-top:20px;color:#8b949e;font-size:13px}
a{color:#58a6ff}
</style>
</head>
<body>
<h1>Login</h1>
<?php
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    if ($user === 'budi' && $pass === 'budi123') {
        setcookie('username', 'budi', 0, '/');
        setcookie('role', 'user', 0, '/');
        header('Location: /dashboard.php');
        exit;
    }
    $error = 'Username atau password salah.';
}
?>
<?php if ($error): ?>
<p class="error"><?php echo $error; ?></p>
<?php endif; ?>
<form method="POST" action="/">
    <label>Username</label>
    <input type="text" name="username" autocomplete="off">
    <label>Password</label>
    <input type="password" name="password">
    <button type="submit">Login</button>
</form>
<div class="info">
    <p>Akun tersedia: <b>budi</b> / <b>budi123</b></p>
    <p>Tapi flag hanya muncul di dashboard admin...</p>
</div>
</body>
</html>
