<!DOCTYPE html>
<html>
<head><title>Dashboard</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:700px;margin:auto}
h1{color:#58a6ff}
.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}
.flag{color:#f0c040;font-size:1.1em}
.role{color:#3fb950;font-weight:bold}
.denied{border-color:#f85149;color:#f85149}
a{color:#58a6ff}
</style>
</head>
<body>
<?php
$username = $_COOKIE['username'] ?? null;
$role     = $_COOKIE['role'] ?? null;

if (!$username) {
    header('Location: /');
    exit;
}
?>
<h1>Dashboard</h1>
<div class="box">
    <p>Selamat datang, <b><?php echo htmlspecialchars($username); ?></b></p>
    <p>Role kamu: <span class="role"><?php echo htmlspecialchars($role); ?></span></p>
</div>

<?php if ($role === 'admin'): ?>
<div class="box">
    <h2>Admin Panel</h2>
    <p>Flag: <span class="flag">CYBER{c00k13_r0l3_cl13nt_s1d3_n0t_s4f3}</span></p>
</div>
<?php else: ?>
<div class="box denied">
    <p>Kamu tidak memiliki akses admin.</p>
    <p style="font-size:13px;color:#8b949e">Hanya role <b>admin</b> yang bisa melihat flag.</p>
</div>
<?php endif; ?>

<p><a href="/">Logout</a></p>
</body>
</html>
