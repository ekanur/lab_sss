<!DOCTYPE html>
<html>
<head><title>Admin Panel</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:700px;margin:auto}
h1{color:#3fb950}.flag{color:#f0c040;font-size:1.1em}
.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}
.denied{color:#f85149}.muted{color:#8b949e;font-size:13px}
a{color:#58a6ff}
</style>
</head>
<body>
<?php
$ip = '';
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$internal = ($ip === '127.0.0.1' || $ip === '::1' || $ip === 'localhost');

if ($internal) {
    echo '<h1>Admin Panel</h1>';
    echo '<div class="box">';
    echo '<p>Access granted. Welcome, internal user!</p>';
    echo '<p>Flag: <span class="flag">CYBER{h34d3r_m4n1pul4t10n_x_f0rw4rd3d_f0r}</span></p>';
    echo '</div>';
} else {
    http_response_code(403);
    echo '<h1 class="denied">403 Forbidden</h1>';
    echo '<div class="box">';
    echo '<p>Halaman ini hanya dapat diakses dari jaringan internal.</p>';
    echo '<p class="muted">Detected IP: <b>' . htmlspecialchars($ip) . '</b></p>';
    echo '<p class="muted">Required: 127.0.0.1</p>';
    echo '</div>';
    echo '<p><a href="/">Kembali</a></p>';
}
?>
</body>
</html>
