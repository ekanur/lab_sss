<!DOCTYPE html>
<html>
<head><title>PT Nusantara — Portal</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:700px;margin:auto}
h1{color:#58a6ff}a{color:#58a6ff}
.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}
.muted{color:#8b949e;font-size:13px}
</style>
</head>
<body>
<h1>PT Nusantara — Internal Portal</h1>
<div class="box">
  <p>Selamat datang di portal internal PT Nusantara.</p>
  <p>Halaman admin hanya dapat diakses dari jaringan internal perusahaan.</p>
  <p>Admin Panel: <a href="/admin.php">/admin.php</a></p>
</div>
<p class="muted">Your IP: <?php echo htmlspecialchars($_SERVER['REMOTE_ADDR']); ?></p>
</body>
</html>
