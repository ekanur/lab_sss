<!DOCTYPE html>
<html>
<head><title>Perpustakaan Digital v2</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:900px;margin:auto}
h1{color:#58a6ff}
input{padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;width:320px}
button{padding:8px 18px;background:#1f6feb;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-left:8px}
table{width:100%;border-collapse:collapse;margin-top:20px}
th{background:#21262d;padding:10px;text-align:left;color:#8b949e;font-size:13px}
td{padding:10px;border-bottom:1px solid #21262d}
.query{background:#161b22;border:1px solid #30363d;padding:12px;border-radius:4px;margin:15px 0;font-size:13px;color:#8b949e;word-break:break-all}
.error{color:#f85149;background:#161b22;border:1px solid #f85149;padding:12px;border-radius:4px;margin:15px 0}
.blocked{color:#f0c040;background:#161b22;border:1px solid #f0c040;padding:12px;border-radius:4px;margin:15px 0}
.info{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin:20px 0;font-size:13px;color:#8b949e}
</style>
</head>
<body>
<h1>Perpustakaan Digital v2 <span style="font-size:14px;color:#3fb950">[Patched]</span></h1>
<?php
$db = new SQLite3('/data/libraryv2.db');
$db->exec("PRAGMA journal_mode=WAL;");
$db->exec("CREATE TABLE IF NOT EXISTS books (id INTEGER, title TEXT, author TEXT, year TEXT, genre TEXT)");
$db->exec("CREATE TABLE IF NOT EXISTS classified (id INTEGER, code TEXT, content TEXT)");
if ($db->querySingle("SELECT COUNT(*) FROM books") == 0) {
    $db->exec("INSERT INTO books VALUES (1,'Web Security Handbook','Budi Santoso','2023','Security')");
    $db->exec("INSERT INTO books VALUES (2,'Python Fundamentals','Siti Rahayu','2022','Programming')");
    $db->exec("INSERT INTO books VALUES (3,'Network Administration','Ahmad Fauzi','2023','Networking')");
    $db->exec("INSERT INTO classified VALUES (1,'DOC-X01','CYBER{f1lt3r_byp4ss_c4s3_v4r14t10n_w1ns}')");
}

$q = $_GET['q'] ?? '';
$results = [];
$error = '';
$blocked = false;
$sql_shown = '';

function is_sqli($input) {
    $blacklist = ['union', 'select', 'insert', 'drop', 'delete', 'update', '--', '/*'];
    $lower = strtolower($input);
    foreach ($blacklist as $kw) {
        if (strpos($lower, $kw) !== false) return true;
    }
    return false;
}

if ($q !== '') {
    if (is_sqli($q)) {
        $blocked = true;
    } else {
        $sql = "SELECT id, title, author, year, genre FROM books WHERE title LIKE '%" . $q . "%' OR author LIKE '%" . $q . "%'";
        $sql_shown = $sql;
        $res = @$db->query($sql);
        if ($res) {
            while ($row = $res->fetchArray(SQLITE3_ASSOC)) $results[] = $row;
        } else {
            $error = $db->lastErrorMsg();
        }
    }
}
?>
<div class="info">
    <b>Catatan developer:</b> Sistem telah diupgrade dengan WAF (Web Application Firewall) sederhana.
    Keyword berbahaya seperti UNION, SELECT, dan lainnya kini diblokir.
</div>
<form method="GET" action="/">
    <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>" placeholder="Cari judul atau penulis...">
    <button type="submit">Cari</button>
</form>

<?php if ($blocked): ?>
<div class="blocked">🛡 WAF: Input kamu mengandung keyword yang diblokir. Akses ditolak.</div>
<?php elseif ($q !== ''): ?>
<div class="query">SQL: <?php echo htmlspecialchars($sql_shown); ?></div>
<?php if ($error): ?>
<div class="error">Error: <?php echo htmlspecialchars($error); ?></div>
<?php elseif (empty($results)): ?>
<p style="color:#8b949e">Tidak ada buku ditemukan.</p>
<?php else: ?>
<table>
    <tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Tahun</th><th>Genre</th></tr>
    <?php foreach ($results as $r): ?>
    <tr>
        <td><?php echo htmlspecialchars($r['id']); ?></td>
        <td><?php echo htmlspecialchars($r['title']); ?></td>
        <td><?php echo htmlspecialchars($r['author']); ?></td>
        <td><?php echo htmlspecialchars($r['year']); ?></td>
        <td><?php echo htmlspecialchars($r['genre']); ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>
<?php endif; ?>
</body>
</html>
