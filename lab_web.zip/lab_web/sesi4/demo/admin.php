<?php
# admin.php
session_start();
include 'db.php';
setcookie('admin_session', 'CYBER{ch41n3d_sqli_xss_4dm1n_pwn3d}', 0, '/');
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
    header('Location: /'); exit;
}
$secret = $db->querySingle("SELECT key_value FROM admin_secrets WHERE id=1");
?>
<!DOCTYPE html><html><head><title>Admin Dashboard</title>
<style>body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:800px;margin:auto}h1{color:#f85149}.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}.flag{color:#f0c040;font-size:1.2em}a{color:#58a6ff}</style>
</head><body>
<h1>Admin Dashboard</h1>
<div class="box">
    <p>Welcome, admin!</p>
    <p>Master Flag: <span class="flag"><?php echo htmlspecialchars($secret); ?></span></p>
</div>
<p><a href="/">← Kembali</a></p>
</body></html>
