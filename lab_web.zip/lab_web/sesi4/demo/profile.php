<?php
# profile.php - vulnerable SQLi endpoint (titik masuk step 2)
session_start();
include 'db.php';
if (!isset($_SESSION['user'])) { header('Location: /login.php'); exit; }

$uid = $_GET['id'] ?? '1';
$sql = "SELECT id, username, role FROM users WHERE id=" . $uid;
$row = @$db->querySingle($sql, true);
$error_msg = '';
if (!$row) { $error_msg = $db->lastErrorMsg(); }
?>
<!DOCTYPE html><html><head><title>Profil</title>
<style>body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:700px;margin:auto}h1{color:#58a6ff}.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}.error{color:#f85149;font-size:13px}.muted{color:#8b949e;font-size:13px}a{color:#58a6ff}table{width:100%;border-collapse:collapse}td{padding:8px;border-bottom:1px solid #21262d}</style>
</head><body>
<h1>Profil Pengguna</h1>
<p class="muted">URL: /profile.php?id=<?php echo htmlspecialchars($uid); ?></p>
<div class="box">
<?php if ($error_msg): ?>
<p class="error">Database error: <?php echo htmlspecialchars($error_msg); ?></p>
<?php elseif ($row): ?>
<table>
<tr><td class="muted">ID</td><td><?php echo htmlspecialchars($row['id']); ?></td></tr>
<tr><td class="muted">Username</td><td><?php echo htmlspecialchars($row['username']); ?></td></tr>
<tr><td class="muted">Role</td><td><?php echo htmlspecialchars($row['role']); ?></td></tr>
</table>
<?php else: ?>
<p>User tidak ditemukan.</p>
<?php endif; ?>
</div>
<p><a href="/">Kembali</a></p>
</body></html>
