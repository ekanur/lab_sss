<?php
# register.php
session_start();
include 'db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    if ($u && $p) {
        try {
            $db->exec("INSERT INTO users (username, password, role) VALUES ('" . SQLite3::escapeString($u) . "','" . SQLite3::escapeString($p) . "','customer')");
            $_SESSION['user'] = $u;
            $_SESSION['role'] = 'customer';
            header('Location: /');
            exit;
        } catch (Exception $e) {
            $error = 'Username sudah dipakai.';
        }
    }
}
?>
<!DOCTYPE html><html><head><title>Daftar</title>
<style>body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:500px;margin:auto}h1{color:#58a6ff}input{width:100%;padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;margin:6px 0;box-sizing:border-box}button{padding:10px 24px;background:#238636;color:#fff;border:none;border-radius:4px;cursor:pointer}a{color:#58a6ff}.error{color:#f85149}</style>
</head><body>
<h1>Daftar Akun</h1>
<?php if ($error) echo "<p class='error'>$error</p>"; ?>
<form method="POST"><label>Username</label><input name="username"><label>Password</label><input type="password" name="password"><button type="submit">Daftar</button></form>
<p><a href="/login.php">Sudah punya akun?</a></p>
</body></html>
