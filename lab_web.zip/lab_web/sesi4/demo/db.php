<?php
$db = new SQLite3('/data/shop.db');
$db->exec("PRAGMA journal_mode=WAL;");
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'customer'
)");
$db->exec("CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    author TEXT,
    title TEXT,
    content TEXT,
    created_at TEXT
)");
$db->exec("CREATE TABLE IF NOT EXISTS admin_secrets (
    id INTEGER PRIMARY KEY,
    key_name TEXT,
    key_value TEXT
)");
if ($db->querySingle("SELECT COUNT(*) FROM users") == 0) {
    $db->exec("INSERT INTO users (username, password, role) VALUES
        ('admin', 'adm1n_s3cr3t_2024', 'admin'),
        ('staff_rina', 'rina_staff_pw', 'staff')
    ");
    $db->exec("INSERT INTO announcements (author, title, content, created_at) VALUES
        ('Admin', 'Selamat Datang', 'Selamat datang di Staff Board PT Nusantara!', '2026-08-01 08:00')
    ");
    $db->exec("INSERT INTO admin_secrets VALUES
        (1, 'master_flag', 'CYBER{ch41n3d_sqli_xss_4dm1n_pwn3d}')
    ");
}
