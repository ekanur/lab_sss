<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user']) || !in_array($_SESSION['role'], ['staff','admin'])) {
    header('Location: /'); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    if ($title && $content) {
        $db->exec("INSERT INTO announcements (author, title, content, created_at) VALUES (
            '" . SQLite3::escapeString($_SESSION['user']) . "',
            '" . SQLite3::escapeString($title) . "',
            '" . $content . "',
            '" . date('Y-m-d H:i') . "'
        )");
        header('Location: /announcements.php');
        exit;
    }
}
$posts = [];
$res = $db->query("SELECT * FROM announcements ORDER BY id DESC");
while ($r = $res->fetchArray(SQLITE3_ASSOC)) $posts[] = $r;
?>
<!DOCTYPE html><html><head><title>Staff Board</title>
<style>body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:800px;margin:auto}h1{color:#f0c040}input,textarea{width:100%;padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;margin:6px 0;box-sizing:border-box}textarea{height:80px}button{padding:8px 20px;background:#1f6feb;color:#fff;border:none;border-radius:4px;cursor:pointer}.post{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin:12px 0}.post h3{color:#58a6ff;margin:0 0 6px}.muted{color:#8b949e;font-size:12px}a{color:#58a6ff}</style>
</head><body>
<h1>Staff Board</h1>
<p class="muted">Hanya dapat diakses oleh staff dan admin.</p>
<h2>Posting Pengumuman</h2>
<form method="POST">
    <label>Judul</label><input name="title" required>
    <label>Konten</label><textarea name="content" required></textarea>
    <button>Post</button>
</form>
<h2 style="margin-top:25px">Pengumuman</h2>
<?php foreach ($posts as $p): ?>
<div class="post">
    <h3><?php echo htmlspecialchars($p['title']); ?></h3>
    <p class="muted"><?php echo htmlspecialchars($p['author']); ?> — <?php echo $p['created_at']; ?></p>
    <div style="margin-top:10px"><?php echo $p['content']; ?></div>
</div>
<?php endforeach; ?>
<p style="margin-top:20px"><a href="/">← Kembali</a></p>
</body></html>
