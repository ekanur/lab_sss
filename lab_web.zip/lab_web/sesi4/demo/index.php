<!DOCTYPE html>
<html>
<head><title>PT Nusantara Shop</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:900px;margin:auto}
h1{color:#58a6ff}nav{margin:20px 0}
nav a{color:#58a6ff;margin-right:20px;text-decoration:none;padding:6px 14px;border:1px solid #30363d;border-radius:4px}
nav a:hover{background:#161b22}
.box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}
.products{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin:20px 0}
.product{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px}
.product h3{color:#3fb950;margin:0 0 8px}
.price{color:#f0c040}
</style>
</head>
<body>
<?php
session_start();
include 'db.php';
?>
<h1>PT Nusantara Shop</h1>
<nav>
    <a href="/">Home</a>
    <?php if (isset($_SESSION['user'])): ?>
        <a href="/profile.php">Profil (<?php echo htmlspecialchars($_SESSION['user']); ?>)</a>
        <?php if ($_SESSION['role'] === 'staff' || $_SESSION['role'] === 'admin'): ?>
        <a href="/announcements.php">Staff Board</a>
        <?php endif; ?>
        <?php if ($_SESSION['role'] === 'admin'): ?>
        <a href="/admin.php">Admin</a>
        <?php endif; ?>
        <a href="/logout.php">Logout</a>
    <?php else: ?>
        <a href="/login.php">Login</a>
        <a href="/register.php">Daftar</a>
    <?php endif; ?>
</nav>
<div class="box">
    <p>Selamat datang di PT Nusantara Shop. Toko online terpercaya!</p>
    <?php if (!isset($_SESSION['user'])): ?>
    <p style="color:#8b949e">Silakan login atau daftar untuk berbelanja.</p>
    <?php endif; ?>
</div>
<div class="products">
    <div class="product"><h3>Laptop Gaming</h3><p class="price">Rp 15.000.000</p></div>
    <div class="product"><h3>Mechanical Keyboard</h3><p class="price">Rp 850.000</p></div>
    <div class="product"><h3>Monitor 4K</h3><p class="price">Rp 8.500.000</p></div>
    <div class="product"><h3>Headset Wireless</h3><p class="price">Rp 1.200.000</p></div>
    <div class="product"><h3>Webcam HD</h3><p class="price">Rp 650.000</p></div>
    <div class="product"><h3>USB Hub 7-port</h3><p class="price">Rp 280.000</p></div>
</div>
</body></html>
