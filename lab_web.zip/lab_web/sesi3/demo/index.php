<!DOCTYPE html>
<html>
<head><title>Portal Komunitas — Cari Artikel</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:800px;margin:auto}
h1{color:#58a6ff}
input{padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;width:320px}
button{padding:8px 18px;background:#1f6feb;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-left:8px}
.result-box{background:#161b22;border:1px solid #30363d;padding:20px;border-radius:6px;margin:20px 0}
.articles{margin-top:20px}
.article{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin:10px 0}
.article h3{color:#58a6ff;margin:0 0 8px}
.muted{color:#8b949e;font-size:13px}
</style>
</head>
<body>
<?php
setcookie('session_token', 'CYBER{r3fl3ct3d_xss_c00k13_st34l}', 0, '/');
$q = $_GET['q'] ?? '';
$articles = [
    ['Pengenalan SQL Injection', 'Budi Santoso', 'Memahami dasar-dasar serangan SQL injection...'],
    ['XSS dan Dampaknya', 'Siti Rahayu', 'Cross-site scripting adalah salah satu kerentanan...'],
    ['OWASP Top 10 2023', 'Ahmad Fauzi', 'Daftar 10 kerentanan web paling berbahaya...'],
];
?>
<h1>Portal Komunitas — Cari Artikel</h1>
<form method="GET" action="/">
    <input type="text" name="q" value="<?php echo htmlspecialchars($q); ?>" placeholder="Cari artikel...">
    <button type="submit">Cari</button>
</form>

<?php if ($q !== ''): ?>
<div class="result-box">
    <p>Hasil pencarian untuk: <?php echo $q; ?></p>
</div>
<?php endif; ?>

<div class="articles">
<?php foreach ($articles as $a): ?>
    <?php if ($q === '' || stripos($a[0], $q) !== false || stripos($a[1], $q) !== false): ?>
    <div class="article">
        <h3><?php echo $a[0]; ?></h3>
        <p class="muted">Oleh <?php echo $a[1]; ?></p>
        <p><?php echo $a[2]; ?></p>
    </div>
    <?php endif; ?>
<?php endforeach; ?>
</div>
<p class="muted" style="margin-top:30px">Tip: Coba search "XSS" atau "SQL" untuk melihat artikel terkait.</p>
</body>
</html>
