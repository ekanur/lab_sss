<!DOCTYPE html>
<html>
<head><title>Forum Komunitas</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:800px;margin:auto}
h1{color:#58a6ff}
textarea{width:100%;padding:10px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;box-sizing:border-box;height:100px;resize:vertical}
input[type=text]{width:100%;padding:8px;background:#161b22;color:#c9d1d9;border:1px solid #30363d;border-radius:4px;box-sizing:border-box;margin:6px 0}
button{padding:10px 24px;background:#238636;color:#fff;border:none;border-radius:4px;cursor:pointer;margin-top:10px}
.post{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin:12px 0}
.post-author{color:#58a6ff;font-weight:bold}
.post-time{color:#8b949e;font-size:12px;margin-left:10px}
.success{color:#3fb950;margin:10px 0}
.info{background:#161b22;border:1px solid #30363d;padding:12px;border-radius:4px;font-size:13px;color:#8b949e;margin:15px 0}
a{color:#58a6ff}
</style>
</head>
<body>
<?php
$db_path = '/data/forum.db';
$db = new SQLite3($db_path);
$db->exec("PRAGMA journal_mode=WAL;");
$db->exec("CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    author TEXT,
    content TEXT,
    created_at TEXT
)");
if ($db->querySingle("SELECT COUNT(*) FROM posts") == 0) {
    $db->exec("INSERT INTO posts (author, content, created_at) VALUES
        ('Admin', 'Selamat datang di forum komunitas cyber!', '2026-08-01 09:00'),
        ('budi', 'Halo semua, saya baru bergabung!', '2026-08-01 10:30'),
        ('siti', 'Ada yang mau diskusi soal OWASP Top 10?', '2026-08-01 11:00')
    ");
}

$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $author  = trim($_POST['author'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if ($author !== '' && $content !== '') {
        $db->exec("INSERT INTO posts (author, content, created_at) VALUES (
            '" . SQLite3::escapeString($author) . "',
            '" . $content . "',
            '" . date('Y-m-d H:i') . "'
        )");
        $success = true;
    }
}

$posts = [];
$res = $db->query("SELECT * FROM posts ORDER BY id DESC");
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $posts[] = $row;
}
?>
<h1>Forum Komunitas Cyber</h1>
<div class="info">
    Halaman moderasi ada di <a href="/admin.php">/admin.php</a> — digunakan moderator untuk review semua postingan.
</div>

<h2>Posting Baru</h2>
<?php if ($success): ?>
<p class="success">Postingan berhasil dikirim!</p>
<?php endif; ?>
<form method="POST" action="/">
    <label>Nama</label>
    <input type="text" name="author" placeholder="Nama kamu" required>
    <label>Pesan</label>
    <textarea name="content" placeholder="Tulis pesanmu di sini..." required></textarea>
    <button type="submit">Kirim</button>
</form>

<h2 style="margin-top:30px">Semua Postingan</h2>
<?php foreach ($posts as $p): ?>
<div class="post">
    <span class="post-author"><?php echo htmlspecialchars($p['author']); ?></span>
    <span class="post-time"><?php echo $p['created_at']; ?></span>
    <p style="margin:10px 0 0"><?php echo htmlspecialchars($p['content']); ?></p>
</div>
<?php endforeach; ?>
</body>
</html>
