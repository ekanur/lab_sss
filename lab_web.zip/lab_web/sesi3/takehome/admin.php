<!DOCTYPE html>
<html>
<head><title>Moderasi Forum</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:40px;max-width:800px;margin:auto}
h1{color:#f0c040}
.post{background:#161b22;border:1px solid #30363d;padding:15px;border-radius:6px;margin:12px 0}
.post-author{color:#58a6ff;font-weight:bold}
.post-time{color:#8b949e;font-size:12px;margin-left:10px}
.warning{background:#2a1a00;border:1px solid #f0c040;padding:12px;border-radius:4px;color:#f0c040;font-size:13px;margin:15px 0}
a{color:#58a6ff}
</style>
</head>
<body>
<?php
setcookie('moderator_flag', 'CYBER{st0r3d_xss_m0d3r4t0r_pwn3d}', 0, '/');
$db = new SQLite3('/data/forum.db');
$posts = [];
$res = $db->query("SELECT * FROM posts ORDER BY id ASC");
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $posts[] = $row;
}
?>
<h1>Halaman Moderasi</h1>
<div class="warning">
    ⚠ Halaman ini menampilkan semua postingan tanpa filter untuk keperluan moderasi.
</div>
<p><a href="/">← Kembali ke Forum</a></p>

<?php foreach ($posts as $p): ?>
<div class="post">
    <span class="post-author"><?php echo htmlspecialchars($p['author']); ?></span>
    <span class="post-time"><?php echo $p['created_at']; ?></span>
    <div style="margin-top:10px">
        <?php echo $p['content']; ?>
    </div>
</div>
<?php endforeach; ?>
</body>
</html>
